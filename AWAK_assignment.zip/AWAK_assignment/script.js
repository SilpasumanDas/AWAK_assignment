

document.addEventListener('DOMContentLoaded', function () {
    const togglePassword = document.querySelector('#togglePassword');
    const passwordField = document.querySelector('#password');
    const eyeIcon = document.querySelector('#eyeIcon');

    // Toggle password visibility on click
    togglePassword.addEventListener('click', function () {
        // Toggle the type attribute of the password field
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);

        // Toggle the eye icon between open and closed
        eyeIcon.classList.toggle('fa-eye');
        eyeIcon.classList.toggle('fa-eye-slash');
    });

    // Form validation
    const form = document.querySelector('#loginForm');
    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent form from submitting

        // Clear previous error messages
        const errorMessage = document.querySelector('#errorMessage');
        errorMessage.textContent = '';

        const username = document.querySelector('#username').value.trim();
        const password = document.querySelector('#password').value;

        // Validate the username
        if (!username) {
            errorMessage.textContent += 'Username/Email is required. ';
        } else if (!validateEmail(username)) {
            errorMessage.textContent += 'Please enter a valid email. ';
        }

        // Validate the password
        if (!password) {
            errorMessage.textContent += 'Password is required. ';
        } else if (password.length < 6) {
            errorMessage.textContent += 'Password must be at least 6 characters long. ';
        }

        // If no errors, proceed with form submission
        if (errorMessage.textContent === '') {
            // Show loading spinner
            document.querySelector('#spinner').style.display = 'block';

            // Simulate form submission
            setTimeout(() => {
                document.querySelector('#spinner').style.display = 'none';
                alert('Form submitted successfully!');
                // You can add your API call here
            }, 1000);
        }
    });

    // Function to validate email format
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
});
